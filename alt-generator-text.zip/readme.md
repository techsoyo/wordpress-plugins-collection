# Auto ALT Text Generator for WordPress

Un plugin c## 🚀 Uso
- **Automático**: Solo sube imágenes, el ALT se genera automáticamente
- **Manual**: Ve a Configuración > Auto ALT Text y haz clic en "Actualizar ALT Manualmente"
- **Shortcode**: Usa `[auto_alt_text]` en cualquier página o post

### Ejemplos de Shortcode:
```
[auto_alt_text]
[auto_alt_text button_text="Generar ALT" style="modern"]
[auto_alt_text show_stats="false" style="minimal"]
[auto_alt_text button_text="Procesar Imágenes" style="modern" show_form="true" show_stats="true"]
```

### Parámetros del Shortcode:
- `button_text`: Texto del botón (default: "Generar ALT Text")
- `style`: "default", "modern", o "minimal"
- `show_form`: "true" o "false" - mostrar formulario
- `show_stats`: "true" o "false" - mostrar estadísticasleto que genera automáticamente texto alternativo (ALT) para imágenes en WordPress, mejorando la accesibilidad y SEO de tu sitio web.

## 📁 Estructura de Carpetas
```
alt-generator-text/
├── alt-generator-text.php # Archivo principal (PHP + AJAX)
├── assets/
│   ├── css/
│   │   └── admin.css      # Estilos para el panel de administración
│   └── js/
│       └── admin.js       # Lógica AJAX y JavaScript
├── uninstall.php          # Limpieza al desinstalar
├── .gitignore            # Exclusiones de Git
└── README.md             # Documentación
```

## ✅ Características Completas

### Automático
- ✅ Genera ALT automáticamente al subir imágenes
- ✅ Basado en el nombre del archivo con formato inteligente
- ✅ Se integra perfectamente con el flujo de trabajo de WordPress

### Manual
- ✅ Botón AJAX para actualizar ALT de publicaciones existentes
- ✅ Procesa múltiples posts automáticamente
- ✅ Solo actualiza imágenes que no tienen ALT text
- ✅ Interfaz amigable con mensajes de estado

### Shortcode
- ✅ `[auto_alt_text]` para mostrar en frontend
- ✅ Parámetros personalizables (estilo, texto del botón, etc.)
- ✅ Estadísticas de imágenes con/sin ALT text
- ✅ Tres estilos: default, modern, minimal

### Técnico
- ✅ Código PHP seguro con nonces y validaciones
- ✅ JavaScript moderno con jQuery
- ✅ CSS responsive y profesional
- ✅ Hooks de WordPress utilizados correctamente
- ✅ Función de desinstalación limpia

## 🔧 Requisitos
- WordPress 5.0+
- PHP 7.2+
- jQuery (incluido con WordPress)

## 📋 Instalación
1. Sube la carpeta del plugin a `/wp-content/plugins/`
2. Activa el plugin en el panel de administración de WordPress
3. Ve a Configuración > Auto ALT Text para usar las funciones manuales

## � Uso
- **Automático**: Solo sube imágenes, el ALT se genera automáticamente
- **Manual**: Ve a Configuración > Auto ALT Text y haz clic en "Actualizar ALT Manualmente"

## 🎯 Estado del Proyecto: COMPLETO ✅
Todas las funcionalidades están implementadas y probadas.
